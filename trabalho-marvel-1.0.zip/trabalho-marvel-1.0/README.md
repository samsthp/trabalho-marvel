better version of main
